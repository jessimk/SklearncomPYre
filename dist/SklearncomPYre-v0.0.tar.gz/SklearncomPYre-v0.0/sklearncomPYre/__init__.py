## inititalization
name = "SklearncomPYre"

from SklearncomPYre.train_test_acc_time import train_test_acc_time
from SklearncomPYre.split import split
from SklearncomPYre.comparison_viz import comparison_viz